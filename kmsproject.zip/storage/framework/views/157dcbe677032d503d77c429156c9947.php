<!DOCTYPE html>
<html>
<head>
    <title>Blog Shared</title>
</head>
<body>
    <h3>Hello <?php echo e($userName); ?>,</h3>
    <p>A new blog has been shared with you:</p>
    <h4><?php echo e($blogTitle); ?></h4>
    <p><?php echo e($blogDescription); ?></p>
    <p>Check it out on our website!</p>
    <br>
    <p>Best Regards,<br>Coekms</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\newkms\resources\views/emails/blog_shared.blade.php ENDPATH**/ ?>