<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <h2>Overview</h2>
    <a href="<?php echo e(route('overview.create')); ?>" class="btn btn-success mb-3">Add Section</a>

    <?php $__currentLoopData = $overviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-body">
                 <h3><?php echo e($overview->type); ?></h3>
                <h3><?php echo e($overview->title); ?></h3>

                
                <p><?php echo $overview->content; ?></p>

                
                <?php if(!empty($overview->media)): ?>
                    <?php if($overview->media_type === 'image'): ?>
                        <img src="<?php echo e(asset('storage/' . $overview->media)); ?>" alt="Overview Image" class="img-fluid mt-2">
                    <?php elseif($overview->media_type === 'video'): ?>
                        <video width="100%" controls class="mt-2">
                            <source src="<?php echo e(asset('storage/' . $overview->media)); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                <?php endif; ?>

                
                <form action="<?php echo e(route('overview.destroy', $overview->id)); ?>" method="POST" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger"
                        onclick="return confirm('Are you sure you want to delete this section?');">
                        Delete
                    </button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newkms\resources\views/overview_index.blade.php ENDPATH**/ ?>