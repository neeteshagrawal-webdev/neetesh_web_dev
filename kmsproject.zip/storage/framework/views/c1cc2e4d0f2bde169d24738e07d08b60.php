<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <div class="col-md-2">
    <button onclick="goBack()" class="btn" style="font-size: 18px; background-color: #003366; color: white;  padding: 10px 20px; border-radius: 8px;">
   <i class="bi bi-arrow-left"></i> Back
</button>
</div>      

<div class="card-container" style="margin-bottom: 100px;">
<div class="card-header">
<i class="fas fa-train"></i> KAVACH - Automatic Train Protection System
</div>
<?php $__currentLoopData = $overviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-body">
                <h3><?php echo e($overview->title); ?></h3>

              
                
                <?php if(!empty($overview->media)): ?>
                    <?php if($overview->media_type === 'image'): ?>
                        <img src="<?php echo e(asset('storage/' . $overview->media)); ?>" alt="Overview Image" class="img-fluid mt-2">
                    <?php elseif($overview->media_type === 'video'): ?>
                        <video width="100%" controls class="mt-2">
                            <source src="<?php echo e(asset('storage/' . $overview->media)); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                <?php endif; ?>
                  
                <p><?php echo $overview->content; ?></p>

                
               <!--  <form action="<?php echo e(route('overview.destroy', $overview->id)); ?>" method="POST" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger"
                        onclick="return confirm('Are you sure you want to delete this section?');">
                        Delete
                    </button>
                </form> -->
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="footer">
RAILWAYS | INDIAN RAILWAYS | SAFETY & TECHNOLOGY | 2025
</div>
</div>


<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<style>

.card-container {
/*max-width: 900px;*/
background: #fff;
box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
border-radius: 12px;
padding: 25px;
overflow: hidden;
margin:auto;
}
.card-header {
background: #003366;
color: white;
font-size: 24px;
font-weight: bold;
text-align: center;
padding: 15px;
border-radius: 8px;
}
.card-body {
padding: 20px;
text-align: center;
}
.card-body video, .card-body img {
width: 100%;
max-width: 700px;
display: block;
margin: 15px auto;
border-radius: 8px;
}
.card-body p {
font-size: 16px;
color: #333;
line-height: 1.6;
text-align: justify;
}
.card-body ul {
text-align: left;
padding-left: 20px;
}
.card-body ul li {
font-size: 16px;
margin-bottom: 8px;
color: #003366;
}
.highlight {
font-weight: bold;
color: #d9534f;
}
.footer {
background: #d9534f;
color: white;
text-align: center;
padding: 10px;
font-size: 14px;
font-weight: bold;
border-radius: 8px;
margin-top: 20px;
}
</style>


</div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function goBack() {
        window.history.back(); // This takes the user to the previous page in history
    }
</script><?php /**PATH /home/coekmsin/public_html/resources/views/kavach/overview.blade.php ENDPATH**/ ?>