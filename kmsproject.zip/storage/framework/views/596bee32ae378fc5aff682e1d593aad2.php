<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!-- Begin Page Content -->
                <div class="container-fluid">
 <div class="col-md-2">
<button onclick="goBack()" class="btn btn-dark" style="font-size: 18px; padding: 10px 20px; border-radius: 8px;">
    ⬅ Back
</button>
</div>
      <div class="container">
        <div class="card-custom">
            <div class="card-header">
                <i class="fas fa-broadcast-tower"></i> LTE (Telecommunication) Overview
            </div>
            <?php $__currentLoopData = $overviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-body">
                <h3><?php echo e($overview->title); ?></h3>

              
                
                <?php if(!empty($overview->media)): ?>
                    <?php if($overview->media_type === 'image'): ?>
                        <img src="<?php echo e(asset('storage/' . $overview->media)); ?>" alt="Overview Image" class="img-fluid mt-2">
                    <?php elseif($overview->media_type === 'video'): ?>
                        <video width="100%" controls class="mt-2">
                            <source src="<?php echo e(asset('storage/' . $overview->media)); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                <?php endif; ?>
                  
                <p><?php echo $overview->content; ?></p>

                
          
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    
    
      <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
      <style>
      
        
        .card-custom {
            /*max-width: 700px;*/
            background: #fff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            overflow: hidden;
        }
        .card-header {
            background: #003366;
            color: white;
            font-size: 22px;
            font-weight: bold;
            text-align: center;
            padding: 15px;
        }
        .card-body {
            padding: 20px;
            text-align: center;
        }
        .card-body img {
            width: 100%;
            max-width: 400px;
            display: block;
            margin: 15px auto;
            border-radius: 8px;
        }
        .card-body p {
            font-size: 16px;
            color: #333;
            line-height: 1.6;
            text-align: justify;
        }
        .icons {
            color: #003366;
            font-size: 18px;
            margin-right: 10px;
        }
    </style>

  
                      </div>
                  </div>
                  <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <script>
    function goBack() {
        window.history.back(); // This takes the user to the previous page in history
    }
</script><?php /**PATH C:\xampp\htdocs\newkms\resources\views/lte/overview.blade.php ENDPATH**/ ?>