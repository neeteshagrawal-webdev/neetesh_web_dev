<!DOCTYPE html>
<html>
<head>
    <title>Account Created</title>
</head>
<body>
    <h2>Hello, <?php echo e($user->name); ?></h2>
    <p>Your account has been created successfully.</p>
    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
    <p><strong>Password:</strong> <?php echo e($password); ?></p>
    <p>You can login using the above credentials.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\newkms\resources\views/emails/user_created.blade.php ENDPATH**/ ?>