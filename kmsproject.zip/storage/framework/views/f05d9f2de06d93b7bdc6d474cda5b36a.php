<!DOCTYPE html>
<html>
<head>
    <title>New Vlog Posted</title>
</head>
<body>
    <h2><?php echo e($details['title']); ?></h2>
    <p><?php echo e($details['message']); ?></p>
  
    <p>Check out the new vlog on our platform!</p>
</body>
</html><?php /**PATH /home/coekmsin/public_html/resources/views/emails/blog_posted.blade.php ENDPATH**/ ?>