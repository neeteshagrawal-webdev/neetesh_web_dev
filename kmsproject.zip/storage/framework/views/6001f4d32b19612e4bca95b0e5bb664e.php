<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
 <div class="col-md-2">
    <button onclick="goBack()" class="btn btn-dark" style="font-size: 18px; padding: 10px 20px; border-radius: 8px;">
        ⬅ Back
    </button>
</div>
      <div class="container">
        <div class="card card-custom">
            <div class="card-header" style="background: #003366;">
                <i class="fas fa-wifi"></i> 5G Network Overview
            </div>
              <?php $__currentLoopData = $overviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-body">
                <h3><?php echo e($overview->title); ?></h3>

              
                
                <?php if(!empty($overview->media)): ?>
                    <?php if($overview->media_type === 'image'): ?>
                        <img src="<?php echo e(asset('storage/' . $overview->media)); ?>" alt="Overview Image" class="img-fluid mt-2">
                    <?php elseif($overview->media_type === 'video'): ?>
                        <video width="100%" controls class="mt-2">
                            <source src="<?php echo e(asset('storage/' . $overview->media)); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                <?php endif; ?>
                  
                <p><?php echo $overview->content; ?></p>

                
          
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    
    
      <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
    p{
        color:black;
    }
        .card-custom {
            /*max-width: 700px;*/
            margin: 50px auto;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }
        .card-header {
            
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .card-body p {
            font-size: 14px;
            margin-bottom: 10px;
        }
        .icons {
            color: #003366;
            margin-right: 8px;
        }
    </style>

  
                      </div>
                  </div>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
    function goBack() {
        window.history.back(); // This takes the user to the previous page in history
    }
</script><?php /**PATH /home/coekmsin/public_html/resources/views/5g/overview.blade.php ENDPATH**/ ?>