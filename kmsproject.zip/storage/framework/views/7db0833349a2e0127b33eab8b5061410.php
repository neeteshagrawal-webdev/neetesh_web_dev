 
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold " style="color: #29b853;">Add Notice Message</h6>
            <!-- Add Button -->
            
        </div>
         <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

               <!--  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> -->
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card-body">
          		<form action="<?php echo e(route('notice.message')); ?>" method="POST" enctype="multipart/form-data">
          			<?php echo csrf_field(); ?>
					<div class="form-group">
					<label for="message">Notice Message</label>
					<input type="text" class="form-control" id="message" name="message" placeholder="Enter Message" value="" required>
					</div>
					<button type="submit" class="btn btn-success" >Save</button>
          		</form>
        </div>
    </div>
   


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\mini-kms\resources\views/scroll_message.blade.php ENDPATH**/ ?>