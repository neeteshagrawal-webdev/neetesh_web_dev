<!DOCTYPE html>
<html>
<head>
    <title>Welcome Aboard!</title>
</head>
<body>
    <h2>Hi {{ $user->name }}, Welcome to Our Community!</h2>
    <p>We’re thrilled to have you join us. Our platform is designed to help you connect, learn, and grow.</p>
    <p>If you have any questions, feel free to reach out. We’re here to support you every step of the way!</p>
    <p>Enjoy your journey with us!</p>
    <p>Best regards,</p>
    <p>The Team</p>
</body>
</html>