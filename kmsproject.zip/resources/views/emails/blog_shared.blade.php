<!DOCTYPE html>
<html>
<head>
    <title>Blog Shared</title>
</head>
<body>
    <h3>Hello {{ $userName }},</h3>
    <p>A new blog has been shared with you:</p>
    <h4>{{ $blogTitle }}</h4>
    <p>{{ $blogDescription }}</p>
    <p>Check it out on our website!</p>
    <br>
    <p>Best Regards,<br>Coekms</p>
</body>
</html>
