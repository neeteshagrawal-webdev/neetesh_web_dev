<!DOCTYPE html>
<html>
<head>
    <title>New Vlog Posted</title>
</head>
<body>
    <h2>{{ $details['title'] }}</h2>
    <p>{{ $details['message'] }}</p>
  
    <p>Check out the new vlog on our platform!</p>
</body>
</html>